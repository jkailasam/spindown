/*  This file contains some general settings. */

#define DEVID_PATH "/dev/disk/by-id/"
#define STATS_PATH "/proc/diskstats"

#define CHAR_BUF   256

#define VERSION    "0.4.0"
